// Use your marketplace contract address here
export const marketplaceContractAddress = '0xAB40FA21C7645ADCFcC124e9EeAC1D8a7e02577a';
export const collectionContractAddress = '0x77D2984Ff4db982Ef66ADA3B6438fa718261CeD8'