import React from "react";
import AboutComponent from "../components/AboutComponent";

const about = () => {
  return <AboutComponent />;
};

export default about;
