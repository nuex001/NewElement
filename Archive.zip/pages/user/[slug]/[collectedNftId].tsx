import React from "react";
import CollectedNftComponent from "../../../components/PublicProfile/CollectedNftComponent";

type Props = {};

const CollectedNft = (props: Props) => {
  return <CollectedNftComponent />;
};

export default CollectedNft;
