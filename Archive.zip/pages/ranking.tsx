import React from "react";
import RankingComponent from "../components/RankingComponent";

const Ranking = () => {
  return <RankingComponent />;
};

export default Ranking;
